<template>
    <footer>
        <p> &#169; Simon Brandtman - 2023 </p>
    </footer>
</template>

<style scoped>
footer {
    width: 100%;
    background-color: black;
    color: rgb(239, 194, 194);
    display: flex;
    justify-content: center;
    align-items: center;
    align-content: center;
    position: relative;
    bottom: 0;
    right: 0;
    text-align: center;
    font-size: 0.8em;
    margin-top: 10px;
}
</style>