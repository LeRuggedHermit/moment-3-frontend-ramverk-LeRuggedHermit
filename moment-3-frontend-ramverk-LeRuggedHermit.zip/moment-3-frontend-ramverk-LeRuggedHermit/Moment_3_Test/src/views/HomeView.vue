

<template>
    <div>
        <article>
<h2>Om mitt intresse och webbplatsens syfte:</h2>
<h4>En musikmissbrukares verklighet:</h4>
<p>

    jag tycker om musik. Jag har under större delen av mitt liv lyssnat på den, 
    skapat den, lärt ut hur andra kan skapa den (som trumlärare). Kort sagt Musik är en viktig del av mitt liv.
    Syftet med webbplatsen är således överkomplicerat sätt att sammanställa mina smakpreferenser och göra en rekommenderar lista.
    Tack vare formuläret på musik-sidan kan även andra människor bidra med sin goda smak kring vad som borde finnas där.
</p></article></div>
</template>

<script setup>

</script>

<style scoped>
div{
    width: 100%;
display: flex;
flex-direction: column;
align-items: center;
align-content: center;
margin-top: 40px;
}

article{
    width: 300px;
    padding: 25px;
    background-color: whitesmoke;
    border: solid black 2px;
    border-radius: 25px;
}
</style>